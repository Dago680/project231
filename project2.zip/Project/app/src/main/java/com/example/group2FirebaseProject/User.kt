package com.example.group2FirebaseProject

data class User(val id : String ?= null,
                val url: String ?= null)
