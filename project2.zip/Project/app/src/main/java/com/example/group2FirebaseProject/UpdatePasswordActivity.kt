package com.example.group2FirebaseProject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class UpdatePasswordActivity : AppCompatActivity() {

    private lateinit var newPasswordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var updateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_password)

        newPasswordEditText = findViewById(R.id.new_password_edit_text)
        confirmPasswordEditText = findViewById(R.id.confirm_password_edit_text)
        updateButton = findViewById(R.id.update_button)

        updateButton.setOnClickListener {
            val newPassword = newPasswordEditText.text.toString().trim()
            val confirmPassword = confirmPasswordEditText.text.toString().trim()

            if (TextUtils.isEmpty(newPassword) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(
                    this@UpdatePasswordActivity,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT
                ).show()
            } else if (newPassword != confirmPassword) {
                Toast.makeText(
                    this@UpdatePasswordActivity,
                    "Passwords do not match",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this@UpdatePasswordActivity,
                    "Password updated successfully",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }
}